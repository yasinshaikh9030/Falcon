// src/pages/Dashboard.js
import React  , { useState } from "react";
import Sidebar from "../Sidebar/Sidebar";
import Header from "../Header/Header";
import DashboardCards from "../DashboardCards/DashboardCards";
import FeedbackSection from "../FeedbackSection/FeedbackSection";
import ChartView from "../ChartView/ChartView";
import UploadPitch from '../UploadPitch/UploadPitch';
import Mentors from "../mentors/mentors"
import ProfilePage from "../ProfilePage/ProfilePage"


import "../Dashboard/Dashboard.css"; // we'll create this later

const Dashboard = () => {
    const [activeSection, setActiveSection] = useState("dashboard");
  
    const renderSection = () => {
      switch (activeSection) {
        case "header":
          return <Header/>;
        case "profile":
          return <ProfilePage/>;
        case "dashboard":
          return <DashboardCards />;
        case "feedback":
          return <FeedbackSection />;
        case "charts":
          return <ChartView />;
        case "upload":
          return <UploadPitch/>
        case "mentors":
          return <Mentors/>;

        // Add more cases like upload, mentors, etc.
        default:
          return <ProfilePage/>;
      }
    };
  
    return (
      <div className="d-flex">
        <Sidebar onSelect={setActiveSection} />
        <div className="main-content w-100">{renderSection()}</div>
      </div>
    );
  };

// function Dashboard() {
//   return (
//     <div className="dashboard-layout d-flex">
//       <Sidebar />
//       <div className="main-content flex-grow-1">
//         <Header />
//         {/* We’ll plug in DashboardCards, FeedbackSection, ChartView here */}
//         <div className="p-4">
//           <h2>Welcome to the Dashboard</h2>
//           <DashboardCards />
//           <FeedbackSection />
//           <ChartView />
//         </div>
//       </div>
//     </div>
//   );
// }

export default Dashboard;
