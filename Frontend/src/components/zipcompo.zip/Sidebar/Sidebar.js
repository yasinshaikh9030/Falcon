import React from "react";
import { Nav } from "react-bootstrap";
import { House, MessageCircle, BarChart2, UploadCloud, Users, User } from "lucide-react";
import "../Sidebar/Sidebar.css";

const Sidebar = ({ onSelect }) => {
  return (
    <div className="sidebar">
      <Nav defaultActiveKey="dashboard" className="flex-column">
      <Nav.Link eventKey="profile" onClick={() => onSelect("profile")}>
          <User size={18} className="me-2" />
          Profile
        </Nav.Link>
        <Nav.Link eventKey="dashboard" onClick={() => onSelect("dashboard")}>
          <House size={18} className="me-2" />
          Dashboard
        </Nav.Link>
        <Nav.Link eventKey="feedback" onClick={() => onSelect("feedback")}>
          <MessageCircle size={18} className="me-2" />
          Feedback
        </Nav.Link>
        <Nav.Link eventKey="charts" onClick={() => onSelect("charts")}>
          <BarChart2 size={18} className="me-2" />
          Charts
        </Nav.Link>
        <Nav.Link eventKey="upload" onClick={() => onSelect("upload")}>
          <UploadCloud size={18} className="me-2" />
          Upload Pitch
        </Nav.Link>
        <Nav.Link eventKey="mentors" onClick={() => onSelect("mentors")}>
          <Users size={18} className="me-2" />
          Mentors
        </Nav.Link>
      </Nav>
    </div>
  );
};

export default Sidebar;
