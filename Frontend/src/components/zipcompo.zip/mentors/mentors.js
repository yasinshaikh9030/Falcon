// src/components/mentors/mentors.js
import React from 'react';
import './mentors.css';

const Mentors = () => {
  return (
    <div className="mentors-container">
      <h2>Mentor Directory</h2>
      <p>This section will showcase all mentors with their expertise, profile, and availability.</p>
    </div>
  );
};

export default Mentors;
