// src/components/Header.js
import React from "react";

const Header = () => {
  return (
    <div className="bg-light p-3 border-bottom">
      <h4 className="mb-0">Dashboard Overview</h4>
    </div>
  );
};

export default Header;
