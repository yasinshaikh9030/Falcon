// DashboardCards.js
import React from 'react';
import { Card, Row, Col } from 'react-bootstrap';
import './DashboardCards.css';

const DashboardCards = () => {
  return (
    <div className="dashboard-container p-4">
      <Row className="g-4">
        <Col md={4}>
          <Card className="custom-card">
            <Card.Body>
              <Card.Title>Total Views</Card.Title>
              <Card.Text>0</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="custom-card">
            <Card.Body>
              <Card.Title>Total Feedbacks</Card.Title>
              <Card.Text>0</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="custom-card">
            <Card.Body>
              <Card.Title>Avg. Sector Score</Card.Title>
              <Card.Text>0</Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default DashboardCards;
