import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { Card, ListGroup } from 'react-bootstrap';

const FeedbackSection = () => {
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeedback = async () => {
      const feedbackCollection = collection(db, 'mentorFeedback');
      const q = query(feedbackCollection, orderBy('date', 'desc')); // Order by date, most recent first
      const querySnapshot = await getDocs(q);
      const feedbackList = querySnapshot.docs.map(doc => doc.data());
      setFeedback(feedbackList);
      setLoading(false);
    };

    fetchFeedback();
  }, []);

  if (loading) return <p>Loading...</p>;

  return (
    <div className="feedback-section">
      <h3>Mentor Feedback</h3>
      {feedback.length === 0 ? (
        <p>No feedback available</p>
      ) : (
        <ListGroup>
          {feedback.map((item, index) => (
            <ListGroup.Item key={index}>
              <Card>
                <Card.Body>
                  <Card.Title>{item.mentorName}</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">
                    {new Date(item.date.seconds * 1000).toLocaleDateString()}
                  </Card.Subtitle>
                  <Card.Text>{item.feedbackText}</Card.Text>
                </Card.Body>
              </Card>
            </ListGroup.Item>
          ))}
        </ListGroup>
      )}
    </div>
  );
};

export default FeedbackSection;
