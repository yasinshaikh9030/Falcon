import React, { useEffect, useState } from "react";
import "./ProfilePage.css";
import { db } from "../../firebase";
import { collection, query, where, getDocs } from "firebase/firestore";

const ProfilePage = ({ userId }) => {
  const [profile, setProfile] = useState(null);
  const [pitches, setPitches] = useState([]);

  useEffect(() => {
    const fetchProfileData = async () => {
      const userDoc = await getDocs(query(collection(db, "users"), where("uid", "==", userId)));
      if (!userDoc.empty) {
        setProfile(userDoc.docs[0].data());
      }
    };

    const fetchUserPitches = async () => {
      const pitchDocs = await getDocs(query(collection(db, "pitches"), where("userId", "==", userId)));
      setPitches(pitchDocs.docs.map(doc => doc.data()));
    };

    fetchProfileData();
    fetchUserPitches();
  }, [userId]);

  return (
    <div className="profile-page-container">
      {profile && (
        <div className="profile-header">
          <img src={profile.profilePicURL} alt="Profile" className="profile-pic" />
          <div className="profile-info">
            <h2>{profile.name}</h2>
            <p><strong>Startup:</strong> {profile.startupName}</p>
            <p><strong>Location:</strong> {profile.location}</p>
            <p><strong>Role:</strong> {profile.role}</p>
          </div>
        </div>
      )}

      <div className="pitches-section">
        <h3>Uploaded Pitches</h3>
        {pitches.length > 0 ? (
          <div className="pitches-list">
            {pitches.map((pitch, index) => (
              <div key={index} className="pitch-card">
                <h4>{pitch.title}</h4>
                <p>{pitch.description}</p>
                <a href={pitch.fileURL} target="_blank" rel="noopener noreferrer">View Pitch</a>
              </div>
            ))}
          </div>
        ) : (
          <p>No pitches uploaded yet.</p>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;
