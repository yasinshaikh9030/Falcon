import React, { useEffect, useState } from "react";
import { db } from '../../firebase';
import { collection, getDocs } from "firebase/firestore";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Card } from "react-bootstrap";

const ChartView = () => {
  const [chartData, setChartData] = useState([]);
  console.log(chartData); 

  useEffect(() => {
    const fetchChartData = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "viewsLog"));
        const rawData = querySnapshot.docs.map(doc => doc.data());

        // Sample transformation – count views per date
        const viewsByDate = {};
        rawData.forEach(item => {
          const date = item.date || "2025-04-17"; // fallback date
          viewsByDate[date] = (viewsByDate[date] || 0) + 1;
        });

        const formattedData = Object.entries(viewsByDate).map(([date, count]) => ({
          date,
          views: count,
        }));

        setChartData(formattedData);
      } catch (error) {
        console.error("Error fetching chart data:", error);
      }
    };

    fetchChartData();
  }, []);

  return (
    <Card className="mt-4 shadow-sm">
      <Card.Body>
        <Card.Title>Engagement Over Time</Card.Title>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="views" stroke="#007bff" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </Card.Body>
    </Card>
  );
};

export default ChartView;
