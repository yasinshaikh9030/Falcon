// src/components/userDashboard/UploadPitch.js

import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, storage } from '../../firebase'; // ✅ already initialized in firebase.js
import './UploadPitch.css';

const UploadPitch = () => {
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState('');

  const onDrop = useCallback(async (acceptedFiles) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setUploading(true);
    const storageRef = ref(storage, `pitches/${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on('state_changed',
      (snapshot) => {},
      (error) => {
        console.error('Upload failed:', error);
        setMessage('Upload failed.');
        setUploading(false);
      },
      async () => {
        const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
        await addDoc(collection(db, 'pitches'), {
          fileName: file.name,
          fileURL: downloadURL,
          uploadedAt: serverTimestamp(),
        });
        setMessage('Upload successful!');
        setUploading(false);
      }
    );
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  return (
    <div className="upload-container">
      <div {...getRootProps()} className={`dropzone ${isDragActive ? 'active' : ''}`}>
        <input {...getInputProps()} />
        {
          isDragActive
            ? <p>Drop the file here ...</p>
            : <p>Drag & drop your pitch file here, or click to select</p>
        }
      </div>
      {uploading && <p>Uploading...</p>}
      {message && <p>{message}</p>}
    </div>
  );
};

export default UploadPitch;
